/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package covid19_management_system.models;

import java.util.Date;

/**
 *
 * @author HieuPhung
 */
public class CachLyModel {
    private int ID;
    private int IDNhanKhau;
    private Date ngayKhaiCL;
    private String ngayKhaiCLStr;
    private int loaiCL;
    private int mucDoCL;
    private Date ngayBatDauCL;
    private String ngayBatDauCLStr;
    private String diaChiCL;
    private String soPhongCL;
    private String soGiuongCL;
    private String tenNgCungPhCL;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public int getIDNhanKhau() {
        return IDNhanKhau;
    }

    public void setIDNhanKhau(int IDNhanKhau) {
        this.IDNhanKhau = IDNhanKhau;
    }

    public Date getNgayKhaiCL() {
        return ngayKhaiCL;
    }

    public void setNgayKhaiCL(Date ngayKhaiCL) {
        this.ngayKhaiCL = ngayKhaiCL;
    }

    public String getNgayKhaiCLStr() {
        return ngayKhaiCLStr;
    }

    public void setNgayKhaiCLStr(String ngayKhaiCLStr) {
        this.ngayKhaiCLStr = ngayKhaiCLStr;
    }

    public int getLoaiCL() {
        return loaiCL;
    }

    public void setLoaiCL(int loaiCL) {
        this.loaiCL = loaiCL;
    }

    public int getMucDoCL() {
        return mucDoCL;
    }

    public void setMucDoCL(int mucDoCL) {
        this.mucDoCL = mucDoCL;
    }

    public Date getNgayBatDauCL() {
        return ngayBatDauCL;
    }

    public void setNgayBatDauCL(Date ngayBatDauCL) {
        this.ngayBatDauCL = ngayBatDauCL;
    }

    public String getNgayBatDauCLStr() {
        return ngayBatDauCLStr;
    }

    public void setNgayBatDauCLStr(String ngayBatDauCLStr) {
        this.ngayBatDauCLStr = ngayBatDauCLStr;
    }

    public String getDiaChiCL() {
        return diaChiCL;
    }

    public void setDiaChiCL(String diaChiCL) {
        this.diaChiCL = diaChiCL;
    }

    public String getSoPhongCL() {
        return soPhongCL;
    }

    public void setSoPhongCL(String soPhongCL) {
        this.soPhongCL = soPhongCL;
    }

    public String getSoGiuongCL() {
        return soGiuongCL;
    }

    public void setSoGiuongCL(String soGiuongCL) {
        this.soGiuongCL = soGiuongCL;
    }

    public String getTenNgCungPhCL() {
        return tenNgCungPhCL;
    }

    public void setTenNgCungPhCL(String tenNgCungPhCL) {
        this.tenNgCungPhCL = tenNgCungPhCL;
    }
    
  
    
}
